#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype> 
using namespace std;

// define a structure for the course
struct Course {
    string courseNumber;
    string courseTitle;
    string courseDescription;
    vector<string> prerequisites;

    // constructors
    Course() {}
    Course(string number, string title, string description, vector<string> prereqs = {})
        : courseNumber(number), courseTitle(title), courseDescription(description), prerequisites(prereqs) {}
}; // end Course

// define a class for hash table
class HashTable {
private:
    unordered_map<string, Course> courses;

public:
    // constructor
    HashTable() {}

    // insert a course into the hash table
    void Insert(const Course& course) {
        courses[course.courseNumber] = course;
    }

    // retrieve course information given its number
    Course CourseInformation(const string& courseNumber) {
        auto courseIterator = courses.find(courseNumber);
        if (courseIterator != courses.end()) {
            return courseIterator->second;
        }
        else {
            return Course();
        }
    } // /end public

    // function to print all courses in sorted order
    void PrintSampleSchedule() {
        cout << "Course List:" << endl;
        vector<const Course*> sortedCourses;
        for (const auto& pair : courses) {
            sortedCourses.push_back(&pair.second);
        } // end for

        sort(sortedCourses.begin(), sortedCourses.end(),
            [](const Course* a, const Course* b) {
                return a->courseNumber < b->courseNumber;
            });

        for (const auto& course : sortedCourses) {
            cout << course->courseNumber << ": " << course->courseTitle << endl;
        } // end for
    } // end PrintSample Schedule

    // print course information
    void PrintCourseInformation(const string& courseNumber) {
        auto courseIterator = courses.find(courseNumber);
        if (courseIterator == courses.end()) {
            cout << "Course not found." << endl;
            return;
        }

        const Course& course = courseIterator->second;
        cout << course.courseNumber << ": " << course.courseTitle << endl;
        cout << "Description: " << course.courseDescription << endl;

        if (!course.prerequisites.empty()) {
            cout << "Prerequisites: " << endl;
            for (const string& prereq : course.prerequisites) {
                auto prereqCourseIterator = courses.find(prereq);
                if (prereqCourseIterator != courses.end()) {
                    const Course& prereqCourse = prereqCourseIterator->second;
                    cout << "- " << prereqCourse.courseNumber << ": " << prereqCourse.courseTitle << endl;
                } // end if
                else {
                    cout << "- " << prereq << ": Course not found." << endl;
                } // end else
            } // end for
            cout << endl;
        } // end if
        else {
            cout << "No prerequisites." << endl;
        } // end else
    } // end PrintCourseInformation
}; // end HashTable

// function to read course data from a file and populate the hash table
void readCourseDataFromFile(const string& filePath, HashTable& hashTable) {
    ifstream file(filePath);
    if (!file.is_open()) {
        cout << "Error opening file: " << filePath << endl;
        return;
    } // end if

    string line;
    while (getline(file, line)) {
        istringstream ss(line);
        string courseNumber, courseTitle, courseDescripton;
        vector<string> prerequisites;

        getline(ss, courseNumber, ',');
        getline(ss, courseTitle, ',');
        getline(ss, courseDescripton, ',');

        string prereq;
        while (getline(ss, prereq, ',')) {
            prerequisites.push_back(prereq);
        }
        hashTable.Insert(Course(courseNumber, courseTitle, courseDescripton, prerequisites));
    } // end while
    file.close();
} // end readCourseDateFromFile

// helper function to convert a string to uppercase
string toUpperCase(const string& str) {
    string upperStr = str;
    transform(upperStr.begin(), upperStr.end(), upperStr.begin(), ::toupper);
    return upperStr;
} // end toUpperCase

void PrintTitle() {
    cout << endl;
    cout << "-----------------------------" << endl;
    cout << "     ABCU COURSE ADVISING     " << endl;
    cout << "-----------------------------" << endl;
    cout << endl;
} // end PrintTitle

int main() {
    HashTable hashTable;
    
    PrintTitle();
    
    string filePath = "ABCU_Advising_Program_Input.txt";
    int choice = 0;

    while (true) {
        cout << "\nMain Menu" << endl;
        cout << "1. Load Data Structure" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course" << endl;
        cout << "9. Exit" << endl;
        cout << "Enter menu option: ";

        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number." << endl;
            continue;
        } // end if

        switch (choice) {
        case 1:
            readCourseDataFromFile(filePath, hashTable);
            cout << "Data loaded into hash table." << endl;
            break;
        case 2:
            hashTable.PrintSampleSchedule();
            break;
        case 3: {
            string courseNumber;
            cout << "Enter course number: ";
            cin >> courseNumber;
            courseNumber = toUpperCase(courseNumber);
            hashTable.PrintCourseInformation(courseNumber);
            break;
        } // end case 3
        case 9:
            cout << "Goodbye!" << endl;
            return 0;
        default:
            cout << "Invalid option. Please try again." << endl;
        } // end switch
    } // end while
} // end main
