package com.example.projectthree;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {

    private EditText editTextDate;
    private EditText editTextTime;
    private EditText editTextEventName;
    private EditText editTextEventDescription;

    private Button buttonAddEvent;
    private Button buttonResetEvent;
    private Button buttonShowEvents;
    private Button buttonSendSms;
    private HashSet<Event> eventList;

    // Request code for SMS permission
    private static final int REQUEST_SMS_PERMISSION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_events);

        editTextDate = findViewById(R.id.editTextDate);
        editTextTime = findViewById(R.id.editTextTime);
        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDescription = findViewById(R.id.editTextEventDescription);

        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonResetEvent = findViewById(R.id.buttonResetEvent);
        buttonShowEvents = findViewById(R.id.buttonShowEvents);
        buttonSendSms = findViewById(R.id.buttonSendSms);

        // Initialize the eventList as a HashSet
        eventList = new HashSet<>();

        buttonAddEvent.setOnClickListener(v -> addEvent());
        buttonResetEvent.setOnClickListener(v -> resetFields());
        buttonShowEvents.setOnClickListener(v -> showEvents());
        buttonSendSms.setOnClickListener(v -> sendSmsNotification());
    }

    private void addEvent() {
        String eventName = editTextEventName.getText().toString();
        String eventDate = editTextDate.getText().toString();
        String eventTime = editTextTime.getText().toString();
        String eventDescription = editTextEventDescription.getText().toString();

        if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty() || eventDescription.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Event newEvent = new Event(eventName, eventDate, eventTime, eventDescription);

        // Add the event to the eventList
        eventList.add(newEvent);

        Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show();
    }

    private void resetFields() {
        editTextDate.setText("");
        editTextTime.setText("");
        editTextEventName.setText("");
        editTextEventDescription.setText("");
        Toast.makeText(this, "Fields reset!", Toast.LENGTH_SHORT).show();
    }

    private void showEvents() {
        if (eventList.isEmpty()) {
            Toast.makeText(this, "No events to show", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert HashSet to List
        ArrayList<Event> eventListAsList = new ArrayList<>(eventList);

        // Pass the List to the adapter
        EventAdapter eventAdapter = new EventAdapter(eventListAsList);

        RecyclerView recyclerViewEventList = findViewById(R.id.recyclerViewEventList);
        recyclerViewEventList.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewEventList.setAdapter(eventAdapter);

        recyclerViewEventList.scrollToPosition(0);
    }


    private void sendSmsNotification() {
        String eventName = editTextEventName.getText().toString();
        String eventDate = editTextDate.getText().toString();
        String eventTime = editTextTime.getText().toString();

        String message = "Event: " + eventName + "\nDate: " + eventDate + "\nTime: " + eventTime;

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("RECIPIENT_PHONE_NUMBER", null, message, null, null);
                Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission denied. Unable to send SMS", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
