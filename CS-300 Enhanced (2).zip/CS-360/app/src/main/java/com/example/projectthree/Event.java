package com.example.projectthree;

public class Event {
    private final String eventName;
    private final String eventDate;
    private final String eventTime;
    private final String eventDescription;

    public Event(String eventName, String eventDate, String eventTime, String eventDescription) {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.eventDescription = eventDescription;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public String getEventDescription() {
        return eventDescription;
    }
}
