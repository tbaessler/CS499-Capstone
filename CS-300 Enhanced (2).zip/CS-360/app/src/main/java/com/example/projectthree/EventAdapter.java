package com.example.projectthree;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashSet;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Event> eventList;

    // Constructor to pass the list of events
    public EventAdapter(List<Event> eventList) {
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the custom row layout for each event
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.show_events, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Bind the data from the event object to the views
        Event event = eventList.get(position);

        holder.textViewDate.setText(event.getEventDate());
        holder.textViewTime.setText(event.getEventTime());
        holder.textViewEventName.setText(event.getEventName());
        holder.textViewDescription.setText(event.getEventDescription());
    }

    @Override
    public int getItemCount() {
        return eventList.size(); // Return the total number of items in the list
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        // Define views for each item
        TextView textViewDate, textViewTime, textViewEventName, textViewDescription;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            // Map views from event_table_row.xml
            textViewDate = itemView.findViewById(R.id.eventDate);
            textViewTime = itemView.findViewById(R.id.eventTime);
            textViewEventName = itemView.findViewById(R.id.eventName);
            textViewDescription = itemView.findViewById(R.id.eventDescription);
        }
    }
}
