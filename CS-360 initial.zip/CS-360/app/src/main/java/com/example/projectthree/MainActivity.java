package com.example.projectthree;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity  extends AppCompatActivity{
    private EditText editTextDate;
    private EditText editTextTime;
    private EditText editTextEventName;
    private EditText editTextEventDescription;

    private Button buttonAddEvent;
    private Button buttonResetEvent;
    private Button buttonShowEvents;
    private Button buttonSendSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextDate = findViewById(R.id.editTextDate);
        editTextTime = findViewById(R.id.editTextTime);
        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDescription = findViewById(R.id.editTextEventDescription);

        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonResetEvent = findViewById(R.id.buttonResetEvent);
        buttonShowEvents = findViewById(R.id.buttonShowEvents);
        buttonResetEvent = findViewById(R.id.buttonSendSms);

        buttonAddEvent.setOnClickListener(v -> addEvent());
        buttonResetEvent.setOnClickListener(v -> resetFields());
        buttonShowEvents.setOnClickListener(v -> showEvents());
        buttonSendSms.setOnClickListener(v -> sendSmsNotification());
    }

    private void addEvent() {

    }

    private void resetFields() {

    }

    private void showEvents() {

    }

    private void sendSmsNotification() {

    }
}
