package com.example.projectthree;

public class Event {
    private String date;
    private String time;
    private String eventName;
    private String description;

    public Event (String date, String time, String eventName, String description) {
        this.date = date;
        this.time = time;
        this.eventName = eventName;
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getEventName() {
        return eventName;
    }

    public String getDescription() {
        return description;
    }
}
